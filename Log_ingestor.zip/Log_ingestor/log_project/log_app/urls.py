from rest_framework.routers import DefaultRouter
from .views import LogViewSet
from django.urls import path, include


router = DefaultRouter()
router.register(r'logs', LogViewSet)

urlpatterns = [
    path("", include(router.urls)),
    path('log/query/', LogViewSet.as_view({'get': 'list'}), name='log-query'),

]
