from django.db import models

# Create your models here.

class Log(models.Model):
    LEVEL_CHOICES = (
        ('error', 'Error'),
        ('warning', 'Warning'),
        ('info', 'Info'),
        # Add more choices if needed
    )

    timestamp = models.DateTimeField()
    level = models.CharField(max_length=20, choices=LEVEL_CHOICES)
    message = models.TextField()
    resourceId = models.CharField(max_length=100)
    traceId = models.CharField(max_length=50)
    spanId = models.CharField(max_length=50)
    commit = models.CharField(max_length=20)
    parentResourceId = models.CharField(max_length=100, blank=True, null=True)

    def __str__(self):
        return f"{self.timestamp} - {self.level}: {self.message}"

