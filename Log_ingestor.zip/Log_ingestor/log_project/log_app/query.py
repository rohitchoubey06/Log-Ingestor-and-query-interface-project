import requests
import logging
# Make a GET request to the Django REST API endpoint
api_url = "http://127.0.0.1:3000/logs/"  # Replace with your API endpoint
response = requests.get(api_url)

if response.status_code == 200:# Check if the request was successful
    logging.info("Here is the data for api")
    api_data = response.json()  # Convert JSON response to Python dictionary or list

    # Process and work with the fetched data
    for item in api_data:
        print(item)  # Print each item or perform operations
    # quering data on the basis of specific conditions like "level" = "error"
    filtered_data = [item for item in api_data if item.get('level') == 'error']
    print(f"filtered_data:{filtered_data}")
else:
    logging.error(f"Failed to fetch data. Status code: {response.status_code}")


