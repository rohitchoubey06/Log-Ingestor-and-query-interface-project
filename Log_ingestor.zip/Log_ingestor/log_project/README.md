Project Overview:
As per the guidnece I have tried to create a Log Ingestor and Query Interface system using Django Rest Framework.
1) First I created a new project in pycharm, and open it's terminal and created new django project then inside it I created a django app.
2) Then I created my model "Log" for the assignment in models.py following it I made a serializers.py file and created a "LogSerializer" and connected it to our model "Log".
3) After that I built the view "LogViewSet" in views.py and connected it to "Log" and "LogSerializer".
4) Then I performed URL mapping between urls.py of "log_project" and "log_app" and used "router" object to register our view-set. You can also 'log/query/' parameter in the url to get the log data.
5) As per the instructions I used port "3000" to run our django server, by hitting command "python manage.py runserver 3000". 
6) I have made a query.py file inside log_app to query our api_data (as per shown in the video). You can also refer to the video on how I have inserted and queried the data.

This was all about the project and sorry for the late submission as I was out of station when I received the assignment mail as also mentioned and discussed on the given mail, I tried my best to complete the project in a short span of time upto best of my understanding. I once again Thank you for this opportunity to allow me work on this assignment.